package com.codabee.ma_premiere_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
